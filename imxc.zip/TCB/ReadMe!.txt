1. edit config.json, 
   
a. isi wallet kalian dan set mode wd auto, ON jika mau wd otomatis, OFF jika wd manual
   
b. set mode timer/waktu jeda scnsesuaikan waktu kalian mau 1, 2, 3, 4 jam terserah


2. isi nomor akun tele kalian atau bisa copy folder session dari bot tele lain

a. buat list nomor tele di file nomor.txt, jika menggunakan session dari bot tele lain
  
b. jika buat session baru bisa lewat sc bot.py untuk termux dan botvps.py untuk vps


3. install requirements 
  
a. pip install -r requirements.txt




DesKaOne CNI
